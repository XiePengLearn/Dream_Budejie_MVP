package com.tz.dream.budejie.mvp.model.impl;

import com.tz.dream.budejie.mvp.model.MvpModel;

/**
 * Created by Dream on 16/5/26.
 */
public class MvpBaseModel implements MvpModel{

}
