package com.tz.dream.budejie.mvp.view;

/**
 * Created by Dream on 16/5/26.
 */
public interface MvpView {

}
