package com.tz.dream.budejie.pro.base.view;

import com.tz.dream.budejie.mvp.presenter.impl.MvpBasePresenter;
import com.tz.dream.budejie.mvp.view.impl.MvpActivity;

/**
 * BaseActivtiy---是我们项目的activity
 * Created by Dream on 16/5/26.
 */
public abstract class BaseActivtiy<P extends MvpBasePresenter> extends MvpActivity<P>{

}
