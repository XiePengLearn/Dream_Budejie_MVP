package com.tz.dream.budejie.pro.base.view.item;

import android.view.View;
import android.view.ViewGroup;

/**
 * Created by Dream on 16/5/29.
 */
public interface ItemBuilder {

    public View buildAndBind(ViewGroup parent);

}
