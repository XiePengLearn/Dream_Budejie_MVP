package com.tz.dream.budejie.pro.publish.view;

import android.view.View;

import com.tz.dream.budejie.R;
import com.tz.dream.budejie.mvp.presenter.impl.MvpBasePresenter;
import com.tz.dream.budejie.pro.base.view.BaseFragment;

/**
 * Created by Dream on 16/5/27.
 */
public class PublishFragment extends BaseFragment{

    @Override
    public int getContentView() {
        return R.layout.fragment_mine;
    }

    @Override
    public void initContentView(View viewContent) {

    }


}
