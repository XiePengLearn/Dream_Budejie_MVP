package com.tz.dream.budejie.mvp.view.impl;

import com.tz.dream.budejie.mvp.view.MvpView;

/**
 * Created by Dream on 16/5/26.
 */
public abstract class MvpBaseView implements MvpView{

}
